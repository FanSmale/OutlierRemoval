package datamodel;

import java.io.File;
import java.io.RandomAccessFile;
import java.util.Random;

/**
 * <p>
 * Summary: Close the dialog. The message sender could be either a button or X
 * at the right top of respective dialog.
 * <p>
 * Author: <b>Henry</b> zhanghrswpu@163.com <br>
 * Copyright: The source code and all documents are open and free. PLEASE keep
 * this header while revising the program. <br>
 * Organization: <a href=http://www.fansmale.com/>Lab of Machine Learning</a>,
 * SouthWest Petroleum University, Sichuan 610500, China.<br>
 * Progress: OK. Copied from Hydrosimu.<br>
 * Written time: August 15, 2017. <br>
 * Last modify time: August 15, 2017.
 */
public class TrainInfo {
	public int userNum;
	public int itemNum;
	public int trainNumRatings;
	
	/**
	 * User training set
	 */
	public double[][] uTrRatings; //The rating matrix for the user training 
	//public static double[][] uTrRatingsSubMean; // The rating matrix - meanRatingOfTrain
	public int[][] uTrRateInds;//The rating indices for the user training
	public int[] uTrDgr;	//The degrees for the user training
	
	/**
	 * The mean/average value of rating for the training set.
	 * It is equal to sum(trainVector)/trainVector.length
	 */
	public double totalRatingOfTrain;
	public double meanRatingOfTrain;
	public double varianceOfTrain;
	public double rmseOfTrain;
	/**
	 * Store non-zero element of training set as a vector.
	 * It is a compressed version with out considering the position.
	 */
	public double[] trainVector;
	
	/**
	 * The small matrix U.
	 */
	public double[][] subU;

	/**
	 * The small matrix V. U * V approximate R (non-zero part).
	 */
	public double[][] subV;
	
	/********************** Feature Matrix ***********************************/
	/**
	 * The rank of small matrices. It is often 2 or 4. It is also the number of
	 * latent variable.
	 */
	public int rank;
	
	/**
	 * Number of Gaussian noise.
	 */
	public int numNoise;
	
	/**
	 * The noise type of each rating. [0.2, 0.1, 0.7] indicates that the
	 * probability is 0.2 for the first noise.
	 */
	double[][] initialRatingsNoiseDistribution;
	
	/**
	 * The weight of every noise.
	 */
	public double[] noiseWeight;
	
	public String splitStr;
	
	/**
	 * 
	 * @param paraFileName
	 * @throws Exception
	 */
	public TrainInfo(String paraFileName, 
			int paraUserNum, int paraItemNum, String paraSplitStr) throws Exception{
		userNum = paraUserNum;
		itemNum = paraItemNum;
		splitStr = paraSplitStr;
		File tempFile = null;
		String tempString = null;
		String[] tempStrArray = null;

		// Compute values of arrays
		tempFile = new File(paraFileName);
		if (!tempFile.exists()) {
			System.out.println("File is not exist!");
			return;
		}// Of if

		RandomAccessFile tempRanFile = new RandomAccessFile(tempFile, "r");
		// ���ļ�����ʼλ��
		int tempBeginIndex = 0;
		// �����ļ��Ŀ�ʼλ���Ƶ�beginIndexλ�á�
		tempRanFile.seek(tempBeginIndex);

		// Step 1. count the item degree
		int tempUserIndex = 0;
		int tempItemIndex = 0;
		double tempRating = 0;
		
		uTrDgr = new int[userNum];
		uTrRatings = new double[userNum][];
		uTrRateInds = new int[userNum][];
		while ((tempString = tempRanFile.readLine()) != null) {
			tempStrArray = tempString.split(splitStr);
			//tempUserIndex = Integer.parseInt(tempStrArray[0]) - 1;
			tempUserIndex = Integer.parseInt(tempStrArray[0]) ;
			uTrDgr[tempUserIndex] ++;
			trainNumRatings ++;
		}// Of while
		
		for(int i = 0; i < uTrDgr.length; i ++){
			uTrRatings[i] = new double[uTrDgr[i]];
			uTrRateInds[i] = new int[uTrDgr[i]];
			
			uTrDgr[i] = 0;
		}//Of for i
		
		// �����ļ��Ŀ�ʼλ���Ƶ�beginIndexλ�á�
		tempRanFile.seek(tempBeginIndex);
		while ((tempString = tempRanFile.readLine()) != null) {
			tempStrArray = tempString.split(splitStr);
//			tempUserIndex = Integer.parseInt(tempStrArray[0]) - 1;
//			tempItemIndex = Integer.parseInt(tempStrArray[1]) - 1; 
			tempUserIndex = Integer.parseInt(tempStrArray[0]) ;
			tempItemIndex = Integer.parseInt(tempStrArray[1]) ; 
			tempRating = Double.parseDouble(tempStrArray[2]); //*2
			
			uTrRatings[tempUserIndex][uTrDgr[tempUserIndex]] = tempRating;
			uTrRateInds[tempUserIndex][uTrDgr[tempUserIndex]] = tempItemIndex;	

			totalRatingOfTrain += tempRating;
			uTrDgr[tempUserIndex] ++;
		}// Of while
		
		tempRanFile.close();
	}// Of the first constructor
	public int[] getTrainRealIndices() {
		int[] tempTrainRealIndices = new int[trainNumRatings];
		int tempCnt = 0;
		for(int i = 0; i < uTrRateInds.length; i++) {
			for (int j = 0; j < uTrRateInds[i].length; j++) {
				tempTrainRealIndices[tempCnt] = i * itemNum + uTrRateInds[i][j];
				tempCnt++;
			}//Of for j 
			
		}//Of for i 
		return tempTrainRealIndices;
	}//Of getTrainRealIndices
	/**
	 ********************** 
	 * Convert the training set into a vector. The result is stored in
	 * trainVector.
	 * 
	 * @see #generateRandomSubMatrix(int)
	 * @see tool.MatrixOpr#getMedian(double[])
	 ********************** 
	 */
	public void computeTrainVector() {
		trainVector = new double[trainNumRatings];
		
		int tempCnt = 0;
		for (int i = 0; i < uTrRatings.length; i++) {
			for (int j = 0; j < uTrRatings[i].length; j++) {	  
				trainVector[tempCnt] = uTrRatings[i][j];
				tempCnt++;
			}// of for j
		}// of for i
	}// of getTrainVector
	
	/**
	 ********************** 
	 * Compute the average rating of the training set.
	 ********************** 
	 */
	public void computeTrainingSetAverageRating() {
		meanRatingOfTrain = totalRatingOfTrain / trainNumRatings;
		System.out.printf("The mean of original training set:%f\r\n ", meanRatingOfTrain);
	}// Of computeTrainingSetAverageRating
	
	
	public void computeTrainingSetVariance() {
	  varianceOfTrain = 0;
		for(int i = 0; i < trainVector.length; i++) {
			varianceOfTrain += (trainVector[i] - meanRatingOfTrain) * (trainVector[i] - meanRatingOfTrain);
		}//Of for i 
		varianceOfTrain /= trainVector.length;
		System.out.printf("The variance of training set: %f\r\n", varianceOfTrain);
	}//Of computeTrainingSetVariance
	
	public void computeTrainingSetRMSE() {
		  rmseOfTrain = 0;
			for(int i = 0; i < trainVector.length; i++) {
				rmseOfTrain += (trainVector[i] - meanRatingOfTrain) * (trainVector[i] - meanRatingOfTrain);
			}//Of for i 
			rmseOfTrain = Math.sqrt(rmseOfTrain / trainVector.length);
			System.out.printf("The rmse of training set: %f\r\n", rmseOfTrain);
		}//Of computeTrainingSetVariance
		
	/**
	 ********************** 
	 * Recompute the training set. Each rating subtracts the mean value.
	 * In this way the average value would be 0.
	 ********************** 
	 */
	public void recomputeTrainset() {
		for (int i = 0; i < uTrRatings.length; i++) {
			for (int j = 0; j < uTrRatings[i].length; j++) {
				uTrRatings[i][j] =uTrRatings[i][j] - meanRatingOfTrain;
			} // of for j
		} // of for i
		
		for(int i = 0; i < trainVector.length; i ++){
			trainVector[i] -= meanRatingOfTrain;
		}//of for i
	}// Of recomputeTrainset
	
	/**
	 ********************** 
	 * Add the mean rating back so that we can compare the prediction with the actual one.
	 ********************** 
	 */
	public void recoverTrainMatrix() {
		for (int i = 0; i < uTrRatings.length; i++) {
			for (int j = 0; j < uTrRatings[i].length; j++) {
				uTrRatings[i][j] = uTrRatings[i][j] + meanRatingOfTrain;
			} // of for j
		} // of for i
		
		for(int i = 0; i < trainVector.length; i ++){
			trainVector[i] += meanRatingOfTrain;
		}//of for i
	}// of recoverTrainMatrix
	
	/**
	 ********************** 
	 * Generate random sub matrices for initialization.
	 * The elements are subject to the uniform distribution in (-tempMu, tempMu).
	 ********************** 
	 */
	public void generateRandomSubMatrix(int paraRank) {
		rank = paraRank;
		subU = new double[userNum][rank];
		subV = new double[itemNum][rank];

		double tempMedianOfTrain = tool.MatrixOpr.getMedian(trainVector);
		double tempMu = Math.sqrt(Math.abs(tempMedianOfTrain) / rank);
		System.out.println("generateRandomSubMatrix test 0");
		System.out.println(tempMedianOfTrain + ":" + tempMu);
		// Step 1. Generate two gaussian sub-matrices
		for (int j = 0; j < rank; j++) {
			for (int i = 0; i < userNum; i++) {
				subU[i][j] = (double)(Math.random() * 2 * tempMu - tempMu);
			} // of for i

			for (int i = 0; i < itemNum; i++) {
				subV[i][j] = (double)(Math.random() * 2 * tempMu - tempMu);
			} // of for i
		} // of for j
		//SimpleTool.printMatrix(subU);
	}// of generateRandomSubMatrix
	
	/**
	 ********************** 
	 * Set the distribution of the noise on each rating
	 ********************** 
	 */
	public void setRandomNoiseDistribution(int paraNumNoise) {
		numNoise = paraNumNoise;
		Random tempRandom = new Random();
		initialRatingsNoiseDistribution = new double[trainNumRatings][numNoise];
		for (int i = 0; i < trainNumRatings; i++) {
			initialRatingsNoiseDistribution[i][tempRandom.nextInt(numNoise)] = 1;
		} // of for i
		// SimpleTool.printMatrix(initialRatingsNoiseDistribution);
	}// Of setRandomNoiseDistribution
	
	public double[][] getNoiseDistribution(){
		return initialRatingsNoiseDistribution;
	}//Of getNoiseDistribution
	
	/**
	 ********************** 
	 * Compute the weight of each noise
	 ********************** 
	 */
	public void computeWeight() {
		noiseWeight = new double[numNoise];
		for (int j = 0; j < initialRatingsNoiseDistribution[0].length; j++) {
			float tempColSum = 0;
			for (int i = 0; i < initialRatingsNoiseDistribution.length; i++) {
				tempColSum += initialRatingsNoiseDistribution[i][j];
			} // of for i
			noiseWeight[j] = tempColSum / trainNumRatings;
		} // of for j
	}// of computeWeight
	
	
	public double[] getTrainVector(){
		return trainVector;
			
	}//Of getTrainVector
	/**
	 * 
	 * @param args
	 */
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		try {	
			String tempTrain = "data/u1.base";
			TrainInfo tempSoc = new TrainInfo(tempTrain, 943, 1682, "	");
		} catch (Exception ee) {
			ee.printStackTrace();
		} // Of try
	}// Of main
}// Of Class SocialDataModel
