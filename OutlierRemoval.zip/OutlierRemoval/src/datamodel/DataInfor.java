package datamodel;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileWriter;
import java.io.IOException;
import java.io.InputStreamReader;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Random;

//import tool.DistrFun;
import tool.SimpleTool;

/**
 * Store and process the data. Split into training and testing sets, etc.
 * 
 * @author Yuan-yuan Xu, Fan Min
 *
 */
public class DataInfor {

	SimpleDateFormat df = new SimpleDateFormat("yyyyMMdd HH:mm:ss");//设置日期格式
	String date = df.format(new Date());
	/**
	 * The number of users.
	 */
	int numUsers;

	/**
	 * The number of items.
	 */
	int numItems;

	/**
	 * The number of non-zero elements in training set.
	 */
	// public int numTrainingNonZero;

	/**
	 * The number of non-zero elements in testing set.
	 */
	int numTestingSize;
	int numTrainingSize;
	/**
	 * Total number of ratings in the rating matrix.
	 */
	int totalNumRatings;

	/**
	 * Number of Gaussian noise.
	 */
	int numNoise;

	/********************** Feature Matrix ***********************************/
	/**
	 * The rank of small matrices. It is often 2 or 4. It is also the number of
	 * latent variable.
	 */
	int rank;

	/**
	 * The original rating matrix. It is uncompressed. 0 indicates not rated.
	 */
	double[][] ratingMatrix;
	double[] ratingVector;

	/**
	 * The matrix of training set.
	 */
	public double[][] trainMatrix;

	/**
	 * The matrix of testing set.
	 */
	public double[][] testMatrix;

	/**
	 * Indicate which position (row, column) has non-zero values. The elements
	 * usually take values 0 or 1.
	 */
	public double[][] nonZeroIndexMatrix;
	public double[][] nonZeroTestIndexMatrix;
	public double[][] nonZeroTrainIndexMatrix;

//	public int[][] storeOutliersIndices = new int[20][80472];
	/**
	 * The noise type of each rating. [0.2, 0.1, 0.7] indicates that the probability
	 * is 0.2 for the first noise.
	 */
	double[][] initialRatingsNoiseDistribution;

	/**
	 * The weight of every noise.
	 */
	public double[] noiseWeight;

	/**
	 * The absolute position of testing data.
	 */
	private int[] positionOfTestingData;
	private int[] positionOfTrainingData;
	/**
	 * The mean/average value of rating for the training set. It is equal to
	 * sum(trainNonZeroVector)/trainNonZeroVector.length
	 */
	public double meanRatingOfTrain;

	/**
	 * Store non-zero element of training set as a vector. It is a compressed
	 * version with out considering the position.
	 */
	public double[] trainNonZeroVector;
	// public double medianofTrain;

	/**
	 * The small matrix U.
	 */
	public double[][] subU;

	/**
	 * The small matrix V. U * V approximate R (non-zero part).
	 */
	public double[][] subV;

	public static final String SPLIT_SIGN = new String("	");

	/**
	 ********************** 
	 * Read the dataset
	 * 
	 * @param paraFilename
	 *            The file storing the data.
	 * @param paraNumUsers
	 *            Number of users. This might be obtained through scanning the whole
	 *            data. However, the approach requires an additional scanning.
	 *            Therefore we do not adopt it.
	 * @param paraNumItems
	 *            Number of items.
	 * @throws IOException
	 *             It may occur if the given file does not exist.
	 ********************** 
	 */
	public DataInfor(String paraTrainFilename, String paraTestFilename, int paraNumUsers, int paraNumItems) throws IOException {
		numUsers = paraNumUsers;
		numItems = paraNumItems;

		// Initialize matrices
		//ratingMatrix = new double[numUsers][numItems];
		nonZeroIndexMatrix = new double[numUsers][numItems];
		trainMatrix = new double[numUsers][numItems];
		nonZeroTrainIndexMatrix = new double[numUsers][numItems];
		testMatrix = new double[numUsers][numItems];
		nonZeroTestIndexMatrix = new double[numUsers][numItems];

		meanRatingOfTrain = 0;
		numTestingSize = 0;

		// Read the data
		int tempUserIndex, tempItemIndex;
		double tempRating;
		totalNumRatings = 0;
		File file = new File(paraTrainFilename);
		BufferedReader buffRead = new BufferedReader(new InputStreamReader(new FileInputStream(file)));
		while (buffRead.ready()) {
			String str = buffRead.readLine();
			String[] parts = str.split(SPLIT_SIGN);
//			tempUserIndex = Integer.parseInt(parts[0]) - 1;// user id
//			tempItemIndex = Integer.parseInt(parts[1]) - 1;// item id
			tempUserIndex = Integer.parseInt(parts[0]);// user id
			tempItemIndex = Integer.parseInt(parts[1]);
			tempRating = Double.parseDouble(parts[2]);// rating
			trainMatrix[tempUserIndex][tempItemIndex] = tempRating;
			nonZeroTrainIndexMatrix[tempUserIndex][tempItemIndex] = 1;
			numTrainingSize++;
		} // Of while
			// SimpleTool.printMatrix(ratingMatrix);
		observeOriginalTrainMatrix(trainMatrix);
		buffRead.close();
		 file = new File(paraTestFilename);
		 buffRead = new BufferedReader(new InputStreamReader(new FileInputStream(file)));
		while (buffRead.ready()) {
			String str = buffRead.readLine();
			String[] parts = str.split(SPLIT_SIGN);
//			tempUserIndex = Integer.parseInt(parts[0]) - 1;// user id
//			tempItemIndex = Integer.parseInt(parts[1]) - 1;// item id
			tempUserIndex = Integer.parseInt(parts[0]);// user id
			tempItemIndex = Integer.parseInt(parts[1]);
			tempRating = Double.parseDouble(parts[2]);// rating
			testMatrix[tempUserIndex][tempItemIndex] = tempRating;
			nonZeroTestIndexMatrix[tempUserIndex][tempItemIndex] = 1;
			numTestingSize++;
		} // Of while
		// System.out.println("The 0th user original rating:");
		// printVector(ratingMatrix[0]);
		buffRead.close();
		
		nonZeroIndexMatrix = tool.MatrixOpr.Matrix_Add(nonZeroTrainIndexMatrix, nonZeroTestIndexMatrix);
	}// of DataInfor

//	public void printVector(double[] paraVector) {
//		for (int i = 0; i < paraVector.length; i++) {
//			System.out.printf("|%8.5f|", paraVector[i]);
//		} // Of for i
//		System.out.print("*");
//		System.out.println();
//	}// of printMatrix

	/**
	 ********************** 
	 * Get the rating matrix.
	 ********************** 
	 */
	public double[][] getRatingMatrix() {
		return ratingMatrix;
	}// Of getRatingMatrix

	public int getTrainingSize() {
		return numTrainingSize;
	}// Of getTrainSize
	
	public double[][]  getTrainMatrix(){
		return trainMatrix;
	}//Of getTrainMatrix
	
	public void ratingMatrix2Vector(double[][] paraRatingMatrix) {
		ratingVector = new double[totalNumRatings];
		int tempIndex = 0;
		for (int i = 0; i < paraRatingMatrix.length; i++) {// USER
			for (int j = 0; j < paraRatingMatrix[0].length; j++) {// ITEM
				if (paraRatingMatrix[i][j] > 1e-6) {
					ratingVector[tempIndex] = paraRatingMatrix[i][j];
					tempIndex++;
				} // Of if
			} // Of for j
		} // Of for i
	}// Of ratingMatrix2Vector

	/**
	 ********************** 
	 * Get the number of users.
	 ********************** 
	 */
	public int getNumUsers() {
		return numUsers;
	}// Of getNumUsers

	/**
	 ********************** 
	 * Get the number of items.
	 ********************** 
	 */
	public int getNumItems() {
		return numItems;
	}// Of getNumItems

	/**
	 ********************** 
	 * Get the row number of the testing data.
	 * 
	 * @param paraTestingDataIndex
	 *            The index of the testing data. A position in the testing array.
	 ********************** 
	 */
	public int getTestingDataRow(int paraTestingDataIndex) {
		return positionOfTestingData[paraTestingDataIndex] / numItems;
	}// Of getTestingDataRow

	public int getTrainingDataRow(int paraTrainingDataIndex) {
		return positionOfTrainingData[paraTrainingDataIndex] / numItems;
	}// Of getTrainingDataRow

	/**
	 ********************** 
	 * Get the column number of the testing data.
	 * 
	 * @param paraTestingDataIndex
	 *            The index of the testing data. A position in the testing array.
	 ********************** 
	 */
	public int getTestingDataColumn(int paraTestingDataIndex) {
		return positionOfTestingData[paraTestingDataIndex] % numItems;
	}// Of getTestingDataColumn

	public int getTrainingDataColumn(int paraTrainingDataIndex) {
		return positionOfTrainingData[paraTrainingDataIndex] % numItems;
	}// Of getTestingDataColumn

	/**
	 ********************** 
	 * Get the size of the training set, i.e., the number of non-zero ratings.
	 * 
	 * @return the size of the training set.
	 ********************** 
//	 */
//	public int getTrainingSize() {
//		return totalNumRatings - numTestingSize;
//	}// Of getTrainingSize

	/**
	 ********************** 
	 * Get the size of the testing set, i.e., the number of non-zero ratings.
	 * 
	 * @return the size of the testing set.
	 ********************** 
	 */
	public int getTestingSize() {
//		System.out.printf("numTestingSize: %d\r\n", numTestingSize);
		return numTestingSize;
	}// Of getTestingSize

	/**
	 ********************** 
	 * Get the rank of the factorization matrices. It is often 2 or 4.
	 * 
	 * @return the rank.
	 ********************** 
	 */
	public int getLowRank() {
		return rank;
	}// Of getLowRank

	/**
	 ********************** 
	 * Get the number of noises. It is often 3.
	 * 
	 * @return the rank.
	 ********************** 
	 */
	public int getNumNoise() {
		return numNoise;
	}// of getNumNoise

	public double[][] getNoiseDistribution() {
		return initialRatingsNoiseDistribution;
	}

	public double getTotalNum() {
		return totalNumRatings;
	}// Of getTotalNum

	/**
	 ********************** 
	 * Split the data to obtain the training and testing sets, respectively. At the
	 * same time, obtain numTrainingNonZero and numTestingNonZero.
	 * 
	 * @param paraTestProportion
	 *            the proportion of the testing set.
	 * @throws IOException 
	 ********************** 
	 */
//	public void splitTrainAndTest(double paraTestProportion, int paraThresholdForEachColumn) throws IOException {
//		System.out.println("Train:Test = "+ (1-paraTestProportion) +":  "+paraTestProportion);
//		int[] tempIndxOfNonZero = new int[ratingMatrix.length];
//		double tempTestingSizeForCurrentItem = 0;
//		int[] tempRandPerm;
//		int tempThresholdForEachColumn = paraThresholdForEachColumn;
//		int tempPositionIndex = 0;

		
//		File fileTest = new File("TestingSet.txt");
//				FileWriter outTest = new FileWriter(fileTest);
//
//		for (int j = 0; j < ratingMatrix[0].length; j++) {
//			int tempCnt = 0;
//			for (int i = 0; i < ratingMatrix.length; i++) {
//				if (ratingMatrix[i][j] >= 1) {
//					nonZeroIndexMatrix[i][j] = 1;
//					tempIndxOfNonZero[tempCnt] = i;
////					positionOfTrainingData[tempCnt] = i * numItems + j;
//					tempCnt++;
//				} // of if
//			} // of for i
//				// System.out.println("tempCnt:" + tempCnt);
//				// System.out.println("j:" + j);
//			tempRandPerm = new int[tempCnt];
//			tempRandPerm = SimpleTool.generateRandomSequence(tempCnt);
//
//			// Avoid generating all-zero column for the training set
//			if (tempCnt > tempThresholdForEachColumn) {
//				tempTestingSizeForCurrentItem = Math.floor(tempCnt * paraTestProportion);
//			} else if (tempCnt <= tempThresholdForEachColumn && tempCnt > 1 && paraTestProportion > 1e-6) {
//				tempTestingSizeForCurrentItem = 1;
//			} else if (tempCnt == 1) {
//				tempTestingSizeForCurrentItem = 0;
//			} // of if
//			numTestingSize += tempTestingSizeForCurrentItem;
//
//			if (tempTestingSizeForCurrentItem >= 1) {
//				for (int k = 0; k < tempTestingSizeForCurrentItem; k++) {
//					int tempRow = tempIndxOfNonZero[tempRandPerm[k]];
//					testMatrix[tempRow][j] = ratingMatrix[tempRow][j];
//					 
//						outTest.write(+tempRow+"\t");
//						outTest.write(+j+"\t");
//						outTest.write(+testMatrix[tempRow][j]+"\t\r");
//						
//					nonZeroTestIndexMatrix[tempRow][j] = 1;
////					positionOfTestingData[tempPositionIndex] = tempRow * numItems + j;
//					tempPositionIndex++;
//				} // of for k
//			} // of if
//		} // of for j
//		outTest.close();
//			// SimpleTool.printMatrix(nonZeroIndexMatrix);
//		//nonZeroTrainIndexMatrix = tool.MatrixOpr.Matrix_Sub(nonZeroIndexMatrix, nonZeroTestIndexMatrix);
//		// System.out.println("numTrainingNonZero:" + numTrainingNonZero + "," +
//		// "NumofTestNonzero:" + NumofTestNonzero);
//		trainMatrix = tool.MatrixOpr.Matrix_Sub(ratingMatrix, testMatrix);
//		//**********
//		double tempSumTrain = 0;
//		double meanOfTrain = 0, varianceOfTrain = 0;
//		
//		for(int i = 0; i < trainMatrix.length; i++) {
//			for (int j = 0; j < trainMatrix[0].length; j++) {
//				if(trainMatrix[i][j] != 0) {
//					tempSumTrain += trainMatrix[i][j];
//				}//Of if
//			}//Of for j
//		}//Of for i
//		meanOfTrain = tempSumTrain /(totalNumRatings - numTestingSize);
//		System.out.printf("The mean of training set: %.4f\r\n", meanOfTrain);
//		for(int i = 0; i < trainMatrix.length; i++) {
//			for (int j = 0; j < trainMatrix[0].length; j++) {
//				if(trainMatrix[i][j] != 0) {
//					varianceOfTrain += (trainMatrix[i][j] - meanOfTrain) * 
//							(trainMatrix[i][j] - meanOfTrain);
//				}//Of if
//			}//Of for j
//		}//Of for i
//		varianceOfTrain /= totalNumRatings - numTestingSize;
//		System.out.printf("The variance of training set: %.4f\r\n", varianceOfTrain);
//		
	public void positionOfAllData() throws IOException {
		positionOfTrainingData = new int[getTrainingSize()];
		positionOfTestingData = new int[getTestingSize()];
		int tempCntTrain = 0;
		int tempCntTest = 0;
		for(int i = 0; i < numUsers ; i++) {
			for(int j = 0; j < numItems; j++) {
				if(nonZeroTrainIndexMatrix[i][j] == 1) {
					positionOfTrainingData[tempCntTrain] = i * numItems + j;
					tempCntTrain++;
				}//Of if
				if(nonZeroTestIndexMatrix[i][j] == 1 ) {
					positionOfTestingData[tempCntTest] = i * numItems + j;
					tempCntTest++;
				}//Of if
			}//Of for j
			
		}//Of for i 
//		System.out.println("\r\nnumTestingSize in splitTrainAndTest" + numTestingSize);
		
		
		File filePositionOfTrainingData = new File("PositionOfTrainingData.txt");
		FileWriter outPositionOfTrainingData = new FileWriter(filePositionOfTrainingData);
		for (int i = 0; i < positionOfTrainingData.length; i++) {
			outPositionOfTrainingData.write(+positionOfTrainingData[i] + "\r\n");
		} // Of for i
		outPositionOfTrainingData.close();
		
		File filePositionOfTestingData = new File("PositionOfTestingData.txt");
		FileWriter outPositionOfTestingData = new FileWriter(filePositionOfTestingData);
		for (int i = 0; i < positionOfTestingData.length; i++) {
			outPositionOfTestingData.write(+positionOfTestingData[i] + "\r\n");
		} // Of for i
		outPositionOfTestingData.close();
	}// of splitTrainAndTest

	/**
	 ********************** 
	 * Convert the training set into a vector. The result is stored in
	 * trainNonZeroVector.
	 * 
	 * @see #generateRandomSubMatrix(int)
	 * @see tool.MatrixOpr#getMedian(double[])
	 ********************** 
	 */
	public void computeTrainNonZeroVector() {
		double[] tempVector = new double[getTrainingSize()];

		int tempCnt = 0;
		for (int i = 0; i < trainMatrix.length; i++) {
			for (int j = 0; j < trainMatrix[0].length; j++) {
				if (nonZeroTrainIndexMatrix[i][j] != 0) {
					// if (trainMatrix[i][j] > 1e-6) {//This sentence is wrong. Before
					// "computeTrainVector", every element in the trainMatrix
					// has subtracted the mean value, so some elements has become a negative number.
					tempVector[tempCnt] = trainMatrix[i][j];
					tempCnt++;
				} // of if
			} // of for j
		} // of for i
		trainNonZeroVector = new double[tempCnt];
		for (int i = 0; i < tempCnt; i++) {
			trainNonZeroVector[i] = tempVector[i];
		} // Of for i
	}// of gettrainNonZeroVector

	/**
	 ********************** 
	 * Compute the average rating of the training set.
	 ********************** 
	 */
	public void computeTrainingSetAverageRating() {
		double tempSum = tool.MatrixOpr.Matrix_Sum(trainMatrix);
		meanRatingOfTrain = tempSum / getTrainingSize();
	}// Of computeTrainingSetAverageRating

	/**
	 ********************** 
	 * Recompute the training set. Each rating subtracts the mean value. In this way
	 * the average value would be 0.
	 ********************** 
	 */
	public void recomputeTrainset() {
		// int tempCnt = 0;

		for (int i = 0; i < trainMatrix.length; i++) {
			for (int j = 0; j < trainMatrix[0].length; j++) {
				if (nonZeroTrainIndexMatrix[i][j] > 1e-6) {
					trainMatrix[i][j] -= meanRatingOfTrain;
					// tempCnt++;
				} // of if
			} // of for j
		} // of for i
	}// Of recomputeTrainset

	/**
	 ********************** 
	 * Set the distribution of the noise on each rating
	 ********************** 
	 */
	public void setRandomNoiseDistribution(int paraNumNoise) {
		numNoise = paraNumNoise;
		Random tempRandom = new Random();
		initialRatingsNoiseDistribution = new double[getTrainingSize()][numNoise];
		for (int i = 0; i < getTrainingSize(); i++) {
			initialRatingsNoiseDistribution[i][tempRandom.nextInt(numNoise)] = 1;
		} // of for i
			// SimpleTool.printMatrix(initialRatingsNoiseDistribution);
	}// Of setRandomNoiseDistribution

//	public double[][] setRandomNoiseDistribution(int paraNumNoise) {
//		numNoise = paraNumNoise;
//		Random tempRandom = new Random();
//		initialRatingsNoiseDistribution = new double[getTrainingSize()][numNoise];
//		for (int i = 0; i < getTrainingSize(); i++) {
//			initialRatingsNoiseDistribution[i][tempRandom.nextInt(numNoise)] = 1;
//		} // of for i
//		return initialRatingsNoiseDistribution;
//			// SimpleTool.printMatrix(initialRatingsNoiseDistribution);
//	}// Of setRandomNoiseDistribution
	/**
	 ********************** 
	 * Compute the weight of each noise
	 ********************** 
	 */
	public void computeWeight() {
		noiseWeight = new double[numNoise];
		for (int j = 0; j < initialRatingsNoiseDistribution[0].length; j++) {
			double tempColSum = 0;
			for (int i = 0; i < initialRatingsNoiseDistribution.length; i++) {
				tempColSum += initialRatingsNoiseDistribution[i][j];
			} // of for i
			noiseWeight[j] = tempColSum / getTrainingSize();
		} // of for j
	}// of computeWeight

	/**
	 ********************** 
	 * Generate random sub matrices for initialization. The elements are subject to
	 * the uniform distribution in (-tempMu, tempMu).
	 ********************** 
	 */
	public void generateRandomSubMatrix(int paraRank) {
		rank = paraRank;
		subU = new double[numUsers][rank];
		subV = new double[numItems][rank];

		double tempMedianOfTrain = tool.MatrixOpr.getMedian(trainNonZeroVector);
		double tempMu = Math.sqrt(tempMedianOfTrain / rank);
		// Step 1. Generate two gaussian sub-matrices
		for (int j = 0; j < rank; j++) {
			for (int i = 0; i < numUsers; i++) {
				subU[i][j] = Math.random() * 2 * tempMu - tempMu;
			} // of for i

			for (int i = 0; i < numItems; i++) {
				subV[i][j] = Math.random() * 2 * tempMu - tempMu;
			} // of for i
		} // of for j
			// SimpleTool.printMatrix(subU);
	}// of generateRandomSubMatrix

	/**
	 ********************** 
	 * Add the mean rating back so that we can compare the prediction with the
	 * actual one.
	 ********************** 
	 */
	public void recoverTrainMatrix() {
		for (int i = 0; i < trainMatrix.length; i++) {
			for (int j = 0; j < trainMatrix[0].length; j++) {
				if (nonZeroTrainIndexMatrix[i][j] > 1e-6) {
					trainMatrix[i][j] = trainMatrix[i][j] + meanRatingOfTrain;
				} // of if
			} // of for j
		} // of for i
	}// of recoverTrainMatrix

	public void observeOriginalTrainMatrix(double paraMatrix[][]) {
		double tempSum, tempMAE = 0, tempVariance = 0;
		double tempAve;
		double tempTotalNum = getTrainingSize() + getTestingSize();
		tempSum = tool.MatrixOpr.Matrix_Sum(paraMatrix);
		tempAve = tempSum / tempTotalNum;
		System.out.printf("The mean value of R (OriginalTrainMatrix) is %.4f\r\n", tempAve);
		for (int i = 0; i < paraMatrix.length; i++) {
			for (int j = 0; j < paraMatrix[0].length; j++) {
				if (paraMatrix[i][j] > 1e-6) {
					tempMAE += Math.abs(paraMatrix[i][j] - tempAve);
					tempVariance += (paraMatrix[i][j] - tempAve) * (paraMatrix[i][j] - tempAve);
				} // Of if
			} // Of for j
		} // Of for i
		tempMAE /= tempTotalNum;
		tempVariance /= tempTotalNum;
		System.out.printf("The variance  of R (OriginalTrainMatrix) is %.4f\r\n", tempVariance);
		System.out.printf("The MAE of R (OriginalTrainMatrix) between its mean value: %.4f\r\n", tempMAE);
	}

//	public void writeTestingSetToFile() throws IOException {
//		File fileTest = new File("threeVectorOriginalTestingSet"+date+".txt");
//		FileWriter outTest = new FileWriter(fileTest);
//		for (int i = 0; i < numUsers; i++) {
//			for (int j = 0; j < numItems; j++) {
//				if (nonZeroTestIndexMatrix[i][j] != 0) {
//					outTest.write(+i + "\t");
//					outTest.write(+j + "\t");
//					outTest.write(+(int)testMatrix[i][j] + "\r\n");
//				} // Of if
//			} // Of for i
//		} // Of for j
//		outTest.close();
		
//		File fileNotAlignedTest = new File("notAlignedTestingSet.txt");
//		FileWriter outNotAlignedTest = new FileWriter(fileNotAlignedTest);
//		for (int i = 0; i < numUsers; i++) {
//			for (int j = 0; j < numItems; j++) {
//				if (nonZeroTestIndexMatrix[i][j] != 0) {
//					//outNotAlignedTest.write(+i + "\t");
//					//outNotAlignedTest.write(+j + "\t");
//					outNotAlignedTest.write(+(int)testMatrix[i][j] + "\t");
//				} // Of if
//			} // Of for j
//			outNotAlignedTest.write("\r\n");
//		} // Of for i
//		outNotAlignedTest.close();
//	}// Of writeTestingSetToFile

	
	public void writeTrainingSetToFile() throws IOException {
		File fileTrain = new File("threeVectorOriginalTrainingSet"+date+".txt");
		FileWriter outTrain = new FileWriter(fileTrain);
		for (int i = 0; i < numUsers; i++) {
			for (int j = 0; j < numItems; j++) {
				if (nonZeroTrainIndexMatrix[i][j] != 0) {
					outTrain.write(+i + "\t");
					outTrain.write(+j + "\t");
					outTrain.write(+(int)trainMatrix[i][j] + "\r\n");
				} // Of if
			} // Of for j
		} // Of for i
		outTrain.close();
	}// Of writeTrainingSetToFile
	
	public void distributionOfOriginalTrain() {
		int[] tempDistribution = new int[6];
		
		for(int i = 0; i < trainMatrix.length; i++) {
			for (int j = 0; j < trainMatrix[0].length; j++) {
				 
					if(trainMatrix[i][j] == 1) {
						tempDistribution[1]++;
					}
					if(trainMatrix[i][j] == 2) {
						tempDistribution[2]++;
				}
					if(trainMatrix[i][j] == 3) {
					tempDistribution[3]++; 
				} 
					if(trainMatrix[i][j] == 4){
					tempDistribution[4]++; 
				}
					if(trainMatrix[i][j] == 5){
					tempDistribution[5]++;  
				}//Of if
			 
		}//Of for j
	}//Of for i
				System.out.println("The distribution of original train  ");
				for(int i = 0; i < tempDistribution.length; i++) {
					System.out.printf("%d\t", tempDistribution[i]);
	}//Of for i 
				System.out.println("");
}//Of distributionOfOriginalTrain
		 
//		File fileNotAlignedTest = new File("notAlignedTrainingSet.txt");
//		FileWriter outNotAlignedTrian = new FileWriter(fileNotAlignedTest);
//		for (int i = 0; i < numUsers; i++) {
//			for (int j = 0; j < numItems; j++) {
//				if (nonZeroTrainIndexMatrix[i][j] != 0) {
//					//outNotAlignedTest.write(+i + "\t");
//					//outNotAlignedTest.write(+j + "\t");
//					outNotAlignedTrian.write(+(int)testMatrix[i][j] + "\t");
//				} // Of if
//			} // Of for j
//			outNotAlignedTrian.write("\r\n");
//		} // Of for i
//		outNotAlignedTrian.close();
	
	// public static void main(String[] args) {
	// // TODO Auto-generated method stub
	// try {
	// // Step 1. Initialize the train and test data based on group
	// // information
	// String tempFilename = new String("data/ml-100k/u.data");
	//
	// DataInfor tempData = new DataInfor(tempFilename, 943, 1682);
	// tempData.splitTrainAndTest(0.2, 5);
	// tempData.computeTrainingSetAverageRating();
	// tempData.recomputeTrainset();
	// tempData.computeTrainNonZeroVector();
	// tempData.setRandomNoiseDistribution(3);
	// tempData.computeWeight();
	// } catch (Exception e) {
	// e.printStackTrace();
	// } // of try
	// }// of main

}// Of class DataInfor
